#include <msp430.h>
#include <stdint.h>
#include <stdio.h>
#include "serial_msp.h"

volatile unsigned int count=0;
volatile unsigned int ms_delay=0;
int i;

int main(void)
{
  WDTCTL = WDTPW + WDTHOLD;                 // Stop WDT

  DCOCTL  = 0;             // Select lowest DCOx and MODx settings
  BCSCTL1 = CALBC1_1MHZ;   // Set range
  DCOCTL  = CALDCO_1MHZ;   // Set DCO step + modulation

  P1DIR |= 0x40;
  P1REN |= BIT3;
  P1OUT |= BIT3;
  P1IE |= BIT3;
  P1OUT &= ~0x40;
  P1IFG &= ~BIT3;

  TA0CCTL0 = CCIE;                    // CCR0 interrupt enabled
  TA0CCR0 = 1000;                     // 1ms Timer
  TA0CTL = TASSEL_2 + MC_1;           // SMCLK, contmode

  P1SEL  = BIT1 + BIT2;               // Select UART as the pin function
  P1SEL2 = BIT1 + BIT2;
  UCA0CTL1 |= UCSWRST;                // Disable UART module for configuration
  UCA0CTL0 = 0x00;                    // No parity, LSB first, 8-bit data, 1 stop bit, UART, Asynchronous
  UCA0CTL1 = UCSSEL_2 + UCSWRST;      // SMCLK source, keep in reset state
  UCA0BR0 = 104;                      // 9600 Baud rate   - Assumes 1 MHz clock
  UCA0BR1 = 0;                        // 9600 Baud rate   - Assumes 1 MHz clock
  UCA0MCTL = 0x02;                    // 2nd Stage modulation = 1, Oversampling off
  UCA0CTL1 &= ~UCSWRST;               // Enable UART module

  __bis_SR_register(LPM0_bits + GIE);       // Enter LPM0 w/ interrupt

}

/////////////////////////////////////////////
// Timer A0 interrupt service routine
/////////////////////////////////////////////
void __attribute__ ((interrupt(TIMER0_A0_VECTOR))) Timer_A (void)
{
    volatile unsigned int hours = 0, mins = 0, msecs = 0, secs = 0;
    while (1){
    msecs ++;

    if(msecs == 100){
        secs ++;
        msecs = 0;
    }
    if(secs == 60){
        mins ++;
        secs = 0;
    }
    if(mins ==60){
        hours ++;
        mins = 0;
    }
    serial_number (hours);
         serial_string(":");
         serial_number (mins);
         serial_string(":");
         serial_number (secs);
         serial_string("\r");
    }
}


